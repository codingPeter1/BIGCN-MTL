import pandas as pd
import time
start_time = time.time()  # 开始计时

column_names = ['user_id', 'item_id', 'action_time', 'action_type']
# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
    'action_time': str,
    'action_type': int
}

# data: 1 is click, 2 is purchase and 3 is favourite. 4 is comment, 5 is cart
action_type_to_str = {1: 'click', 2: 'purchase', 3: 'favourite', 4: 'comment', 5: 'cart'}


#预训练部分的数据集
part1_df = pd.read_csv('./split_data/JD2019_part1.csv', header=0, names=column_names,dtype=dtype)

#增量块部分的数据集
part2_df = pd.read_csv('./split_data/JD2019_part2.csv', header=0, names=column_names,dtype=dtype)
part3_df = pd.read_csv('./split_data/JD2019_part3.csv', header=0, names=column_names,dtype=dtype)
part4_df = pd.read_csv('./split_data/JD2019_part4.csv', header=0, names=column_names,dtype=dtype)
part5_df = pd.read_csv('./split_data/JD2019_part5.csv', header=0, names=column_names,dtype=dtype)

#合并数据集
combined_df1_2 = pd.concat([part1_df, part2_df])
combined_df_1_2_3 = pd.concat([part1_df, part2_df, part3_df])
combined_df_1_2_3_4 = pd.concat([part1_df, part2_df, part3_df, part4_df])

dic = {'1_2': combined_df1_2, '1_2_3': combined_df_1_2_3, '1_2_3_4': combined_df_1_2_3_4}

for name, df in dic.items():
    df.sort_values(by=['user_id', 'item_id'], inplace=True)
    behavior_types = df['action_type'].unique()
    for behavior in behavior_types:
        behavior_df = df[df['action_type'] == behavior][['user_id', 'item_id']]
        #txt文件
        behavior_df.to_csv(f'./retrain_valid_test_data/JD_txt/{name}/{action_type_to_str[behavior]}.txt', index=False, sep='\t', header=False)
        #csv文件
        behavior_df.to_csv(f'./retrain_valid_test_data/JD_csv/{name}/{action_type_to_str[behavior]}.csv', index=False, sep='\t', header=True)

end_time = time.time()  # 结束计时
print(f'\n\n\n\n\n数据处理完成！总耗时: {end_time - start_time} 秒')