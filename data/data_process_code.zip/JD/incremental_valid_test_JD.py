import pandas as pd
import time
start_time = time.time()  # 开始计时

column_names = ['user_id', 'item_id', 'action_time', 'action_type']
# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
    'action_time': str,
    'action_type': int
}
# data: 1 is click, 2 is purchase and 3 is favourite. 4 is comment, 5 is cart
action_type_to_str = {1: 'click', 2: 'purchase', 3: 'favourite', 4: 'comment', 5: 'cart'}

#预训练部分的数据集
part1_df = pd.read_csv('./split_data/JD2019_part1.csv', header=0, names=column_names,dtype=dtype)
# part1_df.sort_values(by=['user_id', 'item_id'], inplace=True)
# 分离不同行为类型的交互数据
behavior_types = part1_df['action_type'].unique()
for behavior in behavior_types:
    behavior_df = part1_df[part1_df['action_type'] == behavior][['user_id', 'item_id']]
    # 根据 user_id 和 item_id 排序    
    behavior_df.sort_values(by=['user_id', 'item_id'], inplace=True)
    #txt文件
    behavior_df.to_csv(f'./train_valid_test_data/JD_txt/JD2019_part1_{action_type_to_str[behavior]}.txt', index=False, sep='\t', header=False)
    #csv文件
    behavior_df.to_csv(f'./train_valid_test_data/JD_csv/JD2019_part1_{action_type_to_str[behavior]}.csv', index=False, sep='\t', header=True)

#增量块以及验证测试部分的数据集
part2_df = pd.read_csv('./split_data/JD2019_part2.csv', header=0, names=column_names,dtype=dtype)
part3_df = pd.read_csv('./split_data/JD2019_part3.csv', header=0, names=column_names,dtype=dtype)
part4_df = pd.read_csv('./split_data/JD2019_part4.csv', header=0, names=column_names,dtype=dtype)
part5_df = pd.read_csv('./split_data/JD2019_part5.csv', header=0, names=column_names,dtype=dtype)

incremental_df = [part2_df, part3_df, part4_df, part5_df]
for index,df in enumerate(incremental_df, start=2):
    # 分离不同行为类型的交互数据
    behavior_types = df['action_type'].unique()
    for behavior in behavior_types:
        behavior_df = df[df['action_type'] == behavior][['user_id', 'item_id']]
        behavior_df.sort_values(by=['user_id', 'item_id'], inplace=True)
        #txt文件
        behavior_df.to_csv(f'./train_valid_test_data/JD_txt/JD2019_part{index}_{action_type_to_str[behavior]}.txt', index=False, sep='\t', header=False)
        #csv文件
        behavior_df.to_csv(f'./train_valid_test_data/JD_csv/JD2019_part{index}_{action_type_to_str[behavior]}.csv', index=False, sep='\t', header=True)


    # 将 df 分为前半部分和后半部分
    mid_point = len(df) // 2
    first_half = df.iloc[:mid_point]
    second_half = df.iloc[mid_point:]

    # 取出前半部分和后半部分的购买记录
    first_half_purchase = first_half[first_half['action_type'].map(action_type_to_str) == 'purchase']
    second_half_purchase = second_half[second_half['action_type'].map(action_type_to_str) == 'purchase']

    # 将前半部分的购买记录作为验证集，后半部分的购买记录作为测试集
    validation_set = first_half_purchase[['user_id', 'item_id']].copy()
    test_set = second_half_purchase[['user_id', 'item_id']].copy()
    validation_set.sort_values(by=['user_id', 'item_id'], inplace=True)
    test_set.sort_values(by=['user_id', 'item_id'], inplace=True)

    # 保存验证集和测试集到 txt 文件
    validation_set.to_csv(f'./train_valid_test_data/JD_txt/JD2019_part{index}_validation.txt', index=False, sep='\t', header=False)
    test_set.to_csv(f'./train_valid_test_data/JD_txt/JD2019_part{index}_test.txt', index=False, sep='\t', header=False)
    # 保存验证集和测试集到 csv 文件
    validation_set.to_csv(f'./train_valid_test_data/JD_csv/JD2019_part{index}_validation.csv', index=False, sep='\t', header=True)
    test_set.to_csv(f'./train_valid_test_data/JD_csv/JD2019_part{index}_test.csv', index=False, sep='\t', header=True)

end_time = time.time()  # 结束计时
print(f'\n\n数据处理完成！总耗时: {end_time - start_time} 秒')




    

