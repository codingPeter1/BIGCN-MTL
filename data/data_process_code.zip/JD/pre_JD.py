import pandas as pd

if __name__ == '__main__':

    data_directory = '../'
    df = pd.read_csv(data_directory + 'jdata_action.csv', header=None, skiprows=1)
    df.columns = ['user_id', 'item_id', 'action_time', 'module_id', 'action_type']
    df = df.drop(columns=['module_id'])
    df.sort_values(['user_id', 'action_time'], inplace=True)

    # data: 1 is click, 2 is purchase and 3 is favourite. 4 is comment, 5 is cart
    print("==================================== JD =======================================")
    print("============================= init information ================================")
    print("#users:{},#items:{},#behavior_len:{},#click:{},#cart:{},#favourite:{},#purchase:{},#comment:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df),
        len(df[df['action_type'] == 1]),
        len(df[df['action_type'] == 5]),
        len(df[df['action_type'] == 3]),
        len(df[df['action_type'] == 2]),
        len(df[df['action_type'] == 4]),
    ))

    # 对于某条序列，如有重复的(user, item, behavior)记录，只保留时间最早的一条记录
    print("=============================== deduplication =================================")
    df.drop_duplicates(subset=['user_id', 'item_id', 'action_type'], keep='first', inplace=True)
    print("#users:{},#items:{}, #click:{},#cart:{},#favourite:{},#purchase:{},#comment:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['action_type'] == 1]),
        len(df[df['action_type'] == 5]),
        len(df[df['action_type'] == 3]),
        len(df[df['action_type'] == 2]),
        len(df[df['action_type'] == 4]),
    ))

    # 删除action_type为4的行  即删除comment行为
    # df = df[df['action_type'] != 4]

    # 对于某个物品，如果它被购买的次数少于20次，则删除该物品相关的所有记录
    print("========== delect items that have been purchased less than 20 times ===========")
    df['is_buy'] = df['action_type'].map(lambda x: 1 if x == 2 else 0)
    df['valid_item'] = df.item_id.map(df.groupby('item_id')['is_buy'].sum() >= 20)
    df = df.loc[df.valid_item].drop('valid_item', axis=1)
    print("#users:{},#items:{}, #click:{},#cart:{},#favourite:{},#purchase:{},#comment:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['action_type'] == 1]),
        len(df[df['action_type'] == 5]),
        len(df[df['action_type'] == 3]),
        len(df[df['action_type'] == 2]),
        len(df[df['action_type'] == 4]),
    ))

    # 对于某条用户序列，若它包含的购买行为的数量少于5，则删除该条用户序列
    print("========== delete users who have purchased items less than 5 times ============")
    df = df[df.user_id.isin(df[df['action_type'] == 2].user_id.unique())]
    df['valid_session'] = df.user_id.map(df[df['action_type'] == 2].groupby('user_id')['item_id'].size() >= 5)
    df = df.loc[df.valid_session].drop('valid_session', axis=1)
    print("#users:{},#items:{}, #click:{},#cart:{},#favourite:{},#purchase:{},#comment:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['action_type'] == 1]),
        len(df[df['action_type'] == 5]),
        len(df[df['action_type'] == 3]),
        len(df[df['action_type'] == 2]),
        len(df[df['action_type'] == 4]),
    ))

    # 删除comment行为
    print("============================== delect the comment behaviors ======================")
    df = df.drop(df[df['action_type'].isin([4])].index)
    print("#users:{},#items:{},#click:{},#favourite:{},#purchase:{},#cart:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['action_type'] == 1]),
        len(df[df['action_type'] == 3]),
        len(df[df['action_type'] == 2]),
        len(df[df['action_type'] == 5]),
    ))

    df = pd.DataFrame(df, columns=['user_id', 'item_id', 'action_time', 'action_type'])
    df.to_csv('pre_data/JD2019_pre.csv', index=False, header=True)
    # df.to_csv('pre_data/JD2019_pre.txt', index=False, header=True)

    



