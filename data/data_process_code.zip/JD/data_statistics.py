import pandas as pd
import time


start_time = time.time()  # 开始计时

column_names = ['user_id', 'item_id', 'action_time', 'action_type']
# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
    'action_time': str,
    'action_type': int
}

# data: 1 is click, 2 is purchase and 3 is favourite. 4 is comment, 5 is cart
action_type_to_str = {1: 'click', 2: 'purchase', 3: 'favourite', 4: 'comment', 5: 'cart'}

data_name = 'JD2019'

path = './split_data/'
file_name = [data_name+'_pre_delete_u&i_not_in_part1.csv']
            #  ,data_name+'_part1.csv',data_name+'_part2.csv',data_name+'_part3.csv',data_name+'_part4.csv',data_name+'_part5.csv']

# path = './pre_data/'
# file_name = [data_name+'_pre.csv']

# path = '../'
# file_name = ['jdata_action.csv']

# path = './pre_data/'
# file_name = ['UB_pre.csv']

# path = './split_data/'
# file_name = [data_name+'_pre_delete_u&i_not_in_part1.csv']

# total_view = 0
# total_purchase = 0
# total_favourite = 0
# total_cart = 0
# user_count = 0
# item_count = 0

for f in file_name:
    file = path+f
    print(f'正在统计文件: {file}')
    df = pd.read_csv(path+f, header=0, names=column_names,dtype = dtype)
    # df['action_time'] = pd.to_datetime(df['action_time'], format='%Y/%m/%d %H:%M:%S', errors='coerce')
    # 确保action_time为datetime类型
    df['action_time'] = pd.to_datetime(df['action_time'], format='%Y-%m-%d %H:%M:%S', errors='coerce')


    # 统计action_time列的最小时间
    min_action_time = df['action_time'].min()
    print("最小action_time:", min_action_time)
    
    # 统计action_time列的最大时间
    max_action_time = df['action_time'].max()
    print("最大action_time:", max_action_time)

    # 计算时间差（天数）
    days_diff = (max_action_time - min_action_time).days
    print("最大最小action_time相差天数:", days_diff)
    

    print('=====================================')
    #查看最大的 user_id 和 item_id
    num_user_id = len(df['user_id'].unique())
    num_item_id = len(df['user_id'].unique())
    # user_count = max(len(df['user_id'].unique()), user_count)
    # item_count = max(len(df['item_id'].unique()), item_count)
    print(f'用户数量: {len(df['user_id'].unique())}')
    print(f'物品数量: {len(df['item_id'].unique())}')
    print(f'记录总数: {len(df)}')
    print('=====================================')
    # 计算密度
    total_possible_interactions = num_user_id * num_item_id
    actual_interactions = len(df)
    density = actual_interactions / total_possible_interactions
    print(f'数据密度: {density*100:.2f}%')
    print('=====================================')
    # 统计每个行为类型的数据量
    behavior_counts = df['action_type'].value_counts()
    for behavior, count in behavior_counts.items():
        # if action_type_to_str[behavior]== 'click':
        #     total_view += count
        # elif action_type_to_str[behavior] == 'purchase':
        #     total_purchase += count
        # elif action_type_to_str[behavior] == 'favourite':
        #     total_favourite += count
        # elif action_type_to_str[behavior] == 'cart':
        #     total_cart += count
        print(f'行为类型 "{action_type_to_str[behavior]}" 的数据量: {count}')
# print('=====================================')
# print(f'用户数量: {user_count}')
# print(f'物品数量: {item_count}')
# print(f'总点击量: {total_view}')
# print(f'总购买量: {total_purchase}')
# print(f'总收藏量: {total_favourite}')
# print(f'总加入购物车量: {total_cart}')
end_time = time.time()  # 结束计时
print(f'\n\n\n\n\n数据处理完成！总耗时: {end_time - start_time} 秒')