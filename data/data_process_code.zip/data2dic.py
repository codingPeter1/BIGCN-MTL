import json
import os
import random
import shutil

import numpy as np


def generate_dict(path, file):
    user_interaction = {}
    with open(os.path.join(path, file)) as f:
        data = f.readlines()
        for row in data:
            user, item = row.strip().split()
            user, item = int(user), int(item)

            if user not in user_interaction:
                user_interaction[user] = [item]
            elif item not in user_interaction[user]:
                user_interaction[user].append(item)
    return user_interaction


def generate_interact(path):
    buy_dict = generate_dict(path, 'buy.txt')
    with open(os.path.join(path, 'buy_dict.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(buy_dict))

    pv_dict = generate_dict(path, 'view.txt')
    with open(os.path.join(path, 'view_dict.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(pv_dict))
    
    cart_dict = generate_dict(path, 'cart.txt')
    with open(os.path.join(path, 'cart_dict.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(cart_dict))

    for dic in [buy_dict,cart_dict]:
        for k, v in dic.items():
            if k not in pv_dict:
                pv_dict[k] = v
            item = pv_dict[k]
            item.extend(v)
    for k, v in pv_dict.items():
        item = pv_dict[k]
        item = list(set(item))
        pv_dict[k] = sorted(item)

    with open(os.path.join(path, 'all_train_interact_dict.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(pv_dict))

    shutil.copyfile(path+'buy_dict.txt', path+'train_dict.txt')

    validation_dict = generate_dict(path, 'validation.txt')
    with open(os.path.join(path, 'validation_dict.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(validation_dict))

    test_dict = generate_dict(path, 'test.txt')
    with open(os.path.join(path, 'test_dict.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(test_dict))
    
    user_item_count = {"user":35076,"item":17871}
    with open(os.path.join(path, 'count.txt'), 'w', encoding='utf-8') as f:
        f.write(json.dumps(user_item_count))


def generate_all_interact(path):
    all_dict = {}
    files = ['view','cart','buy']
    for file in files:
        with open(os.path.join(path, file+'_dict.txt')) as r:
            data = json.load(r)
            for k, v in data.items():
                if all_dict.get(k, None) is None:
                    all_dict[k] = v
                else:
                    total = all_dict[k]
                    total.extend(v)
                    all_dict[k] = sorted(list(set(total)))
        with open(os.path.join(path, 'all.txt'), 'w') as w1, open(os.path.join(path, 'all_dict.txt'), 'w') as w2:
            for k, v in all_dict.items():
                for i in v:
                    w1.write('{} {}\n'.format(int(k), i))
            w2.write(json.dumps(all_dict))



if __name__ == '__main__':
    for path in ['./0/', './1/', './2/', './3/']:
        generate_interact(path)
        generate_all_interact(path)


