import os
import pandas as pd

if __name__ == '__main__':

    data_directory = '../'
    df = pd.read_csv(os.path.join(data_directory, 'UserBehavior.csv'), header=None)
    df.columns = ['user_id', 'item_id','category_id', 'behavior', 'timestamp']
    df = df.drop(columns=['category_id'])
    df.sort_values(['user_id', 'timestamp'], inplace=True)

    print("===================================== UB ======================================")
    print("============================== init information ===============================")
    print("#user:{},#item:{},view:{},cart:{},fav:{},purchase:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['behavior'] == 'pv']),
        len(df[df['behavior'] == 'cart']),
        len(df[df['behavior'] == 'fav']),
        len(df[df['behavior'] == 'buy']),
    ))

    # 对于某条序列，如有重复的(user, item, behavior)记录，只保留时间最早的一条记录
    print("=============================== deduplication =================================")
    df.drop_duplicates(subset=['user_id', 'item_id', 'behavior'], keep='first', inplace=True)
    print("#user:{},#item:{},view:{},cart:{},fav:{},purchase:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['behavior'] == 'pv']),
        len(df[df['behavior'] == 'cart']),
        len(df[df['behavior'] == 'fav']),
        len(df[df['behavior'] == 'buy']),
    ))

    # 对于某个物品，如果它被购买的次数少于10次，则删除该物品相关的所有记录
    print("========== delect items that have been purchased less than 10 times ===========")
    df['is_buy'] = df['behavior'].map(lambda x: 1 if x == 'buy' else 0)
    df['valid_item'] = df.item_id.map(df.groupby('item_id')['is_buy'].sum() >= 10)
    df = df.loc[df.valid_item].drop('valid_item', axis=1)
    print("#user:{},#item:{},view:{},cart:{},fav:{},purchase:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['behavior'] == 'pv']),
        len(df[df['behavior'] == 'cart']),
        len(df[df['behavior'] == 'fav']),
        len(df[df['behavior'] == 'buy']),
    ))

    # 对于某条用户序列，若它包含的购买行为的数量少于5，则删除该条用户序列
    print("========== delete users who have purchased items less than 5 times ============")
    df = df[df.user_id.isin(df[df['behavior'] == 'buy'].user_id.unique())]
    df['valid_session'] = df.user_id.map(df[df['behavior'] == 'buy'].groupby('user_id')['item_id'].size() >= 5)
    df = df.loc[df.valid_session].drop('valid_session', axis=1)
    print("#user:{},#item:{},view:{},cart:{},fav:{},purchase:{}".format(
        len(df['user_id'].unique()),
        len(df['item_id'].unique()),
        len(df[df['behavior'] == 'pv']),
        len(df[df['behavior'] == 'cart']),
        len(df[df['behavior'] == 'fav']),
        len(df[df['behavior'] == 'buy']),
    ))

    df = pd.DataFrame(df, columns=['user_id', 'item_id', 'timestamp', 'behavior'])
    df.to_csv('./pre_data/UB_pre.csv', index=False, header=True)
    # df.to_csv('pre_data/UB_pre.txt', index=False, header=True)
