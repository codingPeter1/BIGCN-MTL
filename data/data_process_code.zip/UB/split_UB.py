import pandas as pd
import time
start_time = time.time()  # 开始计时

column_names = ['user_id', 'item_id', 'timestamp', 'behavior']
# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
    'timestamp': int,
    'behavior': str
}
df = pd.read_csv('./pre_data/UB_pre.csv', header=0, names=column_names,dtype=dtype)
# 重新编号用户和物品的 ID
df['user_id'], user_id_index = pd.factorize(df['user_id'])
df['item_id'], item_id_index = pd.factorize(df['item_id'])
# # 将编号从 1 开始
df['user_id'] += 1
df['item_id'] += 1

#UB_pre_from_1.csv在这里保存过一次

# 按照 timestamp 列的大小从小到大排序
df = df.sort_values(by='timestamp')

# 计算每个部分的大小
total_length = len(df)
part1_size = int(total_length * 0.60)
part2_size = int(total_length * 0.10)
part3_size = int(total_length * 0.10)
part4_size = int(total_length * 0.10)
part5_size = total_length - part1_size - part2_size - part3_size - part4_size

# 分割数据
part1 = df.iloc[:part1_size]
part2 = df.iloc[part1_size:part1_size + part2_size]
part3 = df.iloc[part1_size + part2_size:part1_size + part2_size + part3_size]
part4 = df.iloc[part1_size + part2_size + part3_size:part1_size + part2_size + part3_size + part4_size]
part5 = df.iloc[part1_size + part2_size + part3_size + part4_size:]

# 获取 part1 中的 user_id 和 item_id
part1_user_ids = part1['user_id'].unique()
part1_item_ids = part1['item_id'].unique()

# 过滤后面四个部分的数据
part2 = part2[part2['user_id'].isin(part1_user_ids) & part2['item_id'].isin(part1_item_ids)]
part3 = part3[part3['user_id'].isin(part1_user_ids) & part3['item_id'].isin(part1_item_ids)]
part4 = part4[part4['user_id'].isin(part1_user_ids) & part4['item_id'].isin(part1_item_ids)]
part5 = part5[part5['user_id'].isin(part1_user_ids) & part5['item_id'].isin(part1_item_ids)]

part1_size = len(part1)
part2_size = len(part2)
part3_size = len(part3)
part4_size = len(part4)
part5_size = len(part5)

# 合并所有部分
combined_df = pd.concat([part1, part2, part3, part4, part5])
# 重新编号用户和物品的 ID
combined_df['user_id'], user_id_index = pd.factorize(combined_df['user_id'])
combined_df['item_id'], item_id_index = pd.factorize(combined_df['item_id'])
# # 将编号从 1 开始
combined_df['user_id'] += 1
combined_df['item_id'] += 1

combined_df.to_csv('./split_data/UB_pre_delete_u&i_not_in_part1.csv', index=False, header=True)


part1 = combined_df.iloc[:part1_size]
part2 = combined_df.iloc[part1_size:part1_size + part2_size]
part3 = combined_df.iloc[part1_size + part2_size:part1_size + part2_size + part3_size]
part4 = combined_df.iloc[part1_size + part2_size + part3_size:part1_size + part2_size + part3_size + part4_size]
part5 = combined_df.iloc[part1_size + part2_size + part3_size + part4_size:]

# 保存每个部分到单独的 CSV 文件
part1.to_csv('./split_data/UserBehavior_part1.csv', index=False)
part2.to_csv('./split_data/UserBehavior_part2.csv', index=False)
part3.to_csv('./split_data/UserBehavior_part3.csv', index=False)
part4.to_csv('./split_data/UserBehavior_part4.csv', index=False)
part5.to_csv('./split_data/UserBehavior_part5.csv', index=False)


end_time = time.time()  # 结束计时
print(f'\n\n\n\n\n数据处理完成！总耗时: {end_time - start_time} 秒')