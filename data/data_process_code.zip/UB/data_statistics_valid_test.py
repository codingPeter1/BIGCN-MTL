import pandas as pd
import time


start_time = time.time()  # 开始计时

column_names = ['user_id', 'item_id']
# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
}

path = './train_valid_test_data/UB_csv/'
data_name = 'UserBehavior'
part = [2,3,4,5]
valid_test = ['validation','test']
file_name = []

for p in part:
    total_num = 0
    print('=====================UB===========================')
    for vt in valid_test:
        file = data_name+'_part'+str(p)+'_'+vt+'.csv'
        df = pd.read_csv(path+file, header=0,dtype=dtype)
        # print(f'{file}文件记录总数: {len(df)}')
        print(f'part{p}部分{vt}记录总数: {len(df)}')
        total_num += len(df)
    original_file = data_name+'_part'+str(p)+'_'+'buy'+'.csv'
    original_df = pd.read_csv(path+original_file, header=0,dtype=dtype)
    # print(f'part{p}部分购买记录总数: {len(original_df)}')
    print(f'part{p}部分验证测试记录总数: {total_num}')

# for f in file_name:
#     df = pd.read_csv(path+f, header=0,dtype = dtype)
#     #统计记录数量
#     print(f'{f}文件记录总数: {len(df)}')


