import pandas as pd
import time
start_time = time.time()  # 开始计时

column_names = ['user_id', 'item_id', 'timestamp', 'behavior']
# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
    'timestamp': int,
    'behavior': str
}

#预训练部分的数据集
part1_df = pd.read_csv('./split_data/UserBehavior_part1.csv', header=0, names=column_names,dtype=dtype)

#增量块部分的数据集
part2_df = pd.read_csv('./split_data/UserBehavior_part2.csv', header=0, names=column_names,dtype=dtype)
part3_df = pd.read_csv('./split_data/UserBehavior_part3.csv', header=0, names=column_names,dtype=dtype)
part4_df = pd.read_csv('./split_data/UserBehavior_part4.csv', header=0, names=column_names,dtype=dtype)
part5_df = pd.read_csv('./split_data/UserBehavior_part5.csv', header=0, names=column_names,dtype=dtype)

#合并数据集
combined_df1_2 = pd.concat([part1_df, part2_df])
combined_df_1_2_3 = pd.concat([part1_df, part2_df, part3_df])
combined_df_1_2_3_4 = pd.concat([part1_df, part2_df, part3_df, part4_df])

dic = {'1_2': combined_df1_2, '1_2_3': combined_df_1_2_3, '1_2_3_4': combined_df_1_2_3_4}

for name, df in dic.items():
    df.sort_values(by=['user_id', 'item_id'], inplace=True)
    behavior_types = df['behavior'].unique()
    for behavior in behavior_types:
        behavior_df = df[df['behavior'] == behavior][['user_id', 'item_id']]
        #txt文件
        behavior_df.to_csv(f'./retrain_valid_test_data/UB_txt/{name}/{behavior}.txt', index=False, sep='\t', header=False)
        #csv文件
        behavior_df.to_csv(f'./retrain_valid_test_data/UB_csv/{name}/{behavior}.csv', index=False, sep='\t', header=True)

end_time = time.time()  # 结束计时
print(f'\n\n\n\n\n数据处理完成！总耗时: {end_time - start_time} 秒')