import pandas as pd
import time

column_names = ['user_id', 'item_id', 'timestamp', 'behavior']

start_time = time.time()  # 开始计时

# 读取整个 CSV 文件，并指定每列的数据类型
dtype = {
    'user_id': int,
    'item_id': int,
    'timestamp': int,
    'behavior': str
}

path = './split_data/'
# file_name = ['UB_pre_delete_u&i_not_in_part1.csv','UserBehavior_part1.csv','UserBehavior_part2.csv','UserBehavior_part3.csv','UserBehavior_part4.csv','UserBehavior_part5.csv']
file_name = ['UserBehavior_part1.csv','UserBehavior_part2.csv','UserBehavior_part3.csv','UserBehavior_part4.csv','UserBehavior_part5.csv']
# file_name = ['UB_pre_delete_u&i_not_in_part1.csv']

# path = './pre_data/'
# file_name = ['UB_pre.csv']

# path = './split_data/'
# file_name = ['UB_pre_delete_u&i_not_in_part1.csv']


for f in file_name:
    file = path+f
    print(f'正在统计文件: {file}')
    df = pd.read_csv(path+f, header=0, names=column_names,dtype = dtype)


    print('=====================================')
    #查看最大的 user_id 和 item_id
    num_user_id = len(df['user_id'].unique())
    num_item_id = len(df['user_id'].unique())
    print(f'用户数量: {len(df['user_id'].unique())}')
    print(f'物品数量: {len(df['item_id'].unique())}')
    print(f'记录总数: {len(df)}')
    print('=====================================')
    # 计算密度
    total_possible_interactions = num_user_id * num_item_id
    actual_interactions = len(df)
    density = actual_interactions / total_possible_interactions
    print(f'数据密度: {density*100:.2f}%')
    print('=====================================')
    # 统计每个行为类型的数据量
    behavior_counts = df['behavior'].value_counts()
    for behavior, count in behavior_counts.items():
        print(f'行为类型 "{behavior}" 的数据量: {count}')


end_time = time.time()  # 结束计时
print(f'\n\n\n\n\n数据处理完成！总耗时: {end_time - start_time} 秒')