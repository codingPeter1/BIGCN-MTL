import pandas as pd
import numpy as np

if __name__ == '__main__':
    file_prefix = 'processed_data_att/Tmall'
    # 只统计总的
    train = pd.read_csv(file_prefix + "_train.csv", header=None, 
                                names=['user_id', 'item_id', 'cat_id', 'seller_id', 'brand_id', 'timestamp', 'action_type'], 
                                dtype={'user_id': np.int32, 'item_id': np.int32, 'cat_id': np.int32, 'seller_id': np.int32, 'brand_id': np.int32, 'timestamp': np.int32, 'action_type': np.int32})
    valid = pd.read_csv(file_prefix + "_valid.csv", header=None, 
                                names=['user_id', 'item_id', 'cat_id', 'seller_id', 'brand_id', 'timestamp', 'action_type'], 
                                dtype={'user_id': np.int32, 'item_id': np.int32, 'cat_id': np.int32, 'seller_id': np.int32, 'brand_id': np.int32, 'timestamp': np.int32, 'action_type': np.int32})

    bet_val_test = pd.read_csv(file_prefix + "_between_val_test.csv", header=None,
                                names=['user_id', 'item_id', 'cat_id', 'seller_id', 'brand_id', 'timestamp', 'action_type'],
                                dtype={'user_id': np.int32, 'item_id': np.int32, 'cat_id': np.int32, 'seller_id': np.int32, 'brand_id': np.int32, 'timestamp': np.int32, 'action_type': np.int32})
    test = pd.read_csv(file_prefix + "_test.csv", header=None,
                        names=['user_id', 'item_id', 'cat_id', 'seller_id', 'brand_id', 'timestamp', 'action_type'],
                        dtype={'user_id': np.int32, 'item_id': np.int32, 'cat_id': np.int32, 'seller_id': np.int32, 'brand_id': np.int32, 'timestamp': np.int32, 'action_type': np.int32})

    df_all = pd.concat([train, valid, bet_val_test, test], axis='index')
    
    
    # 用户数：
    user_len = len(df_all['user_id'].unique())
    # 物品数：
    item_len = len(df_all['item_id'].unique())
    # 总交互数：
    interact_len = df_all.shape[0]
    # 平均长度：
    avg_len = df_all.groupby(['user_id'])['item_id'].size().mean()
    # 密度：
    den = interact_len / (user_len * item_len)
    
    
    print("#users:{},#items:{},#interactions:{},#avg_length:{},#dense:{}".format(user_len, item_len, interact_len, avg_len, den))
    
    
    #users:17209,#items:16170,#interactions:836082,#avg_length:48.583996745888776,#dense:0.003004576174761211