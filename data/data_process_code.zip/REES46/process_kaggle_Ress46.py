#读取.csv文件
import pandas as pd
import numpy as np
import os
import random


def print_statistics(df):
        print("#users:{},#items:{},#view:{},#cart:{},#purchase:{},#dense:{}".format(
            len(df['user_id'].unique()),
            len(df['product_id'].unique()),
            len(df[df['event_type'] == 'view']),
            len(df[df['event_type'] == 'cart']),
            len(df[df['event_type'] == 'purchase']),
            df.shape[0] / (len(df['user_id'].unique()) * len(df['product_id'].unique()))
        ))

def print_statistics2(df):
        print("#users:{},#items:{},#view:{},#cart:{},#purchase:{},#dense:{}".format(
            len(df['user_id'].unique()),
            len(df['item_id'].unique()),
            len(df[df['action_type'] == 0]),
            len(df[df['action_type'] == 1]),
            len(df[df['action_type'] == 2]),
            df.shape[0] / (len(df['user_id'].unique()) * len(df['item_id'].unique()))
        ))

def pre_process(data_directory,kaggle_data,output_file):
    # 读取数据
    df = pd.read_csv(os.path.join(data_directory, kaggle_data))
    # 选择需要的列
    df = df[['user_id', 'product_id', 'event_time','event_type']]
    # 过滤出需要的事件类型
    df = df[df['event_type'].isin(['view', 'cart', 'purchase'])]
    # 根据 'event_time' 列排序
    df = df.sort_values(by='event_time')
    df.to_csv(output_file, index=False)
    return df

# data_directory = './'
# kaggle_data = '2020-Apr.csv'
# output_file = f"./proceessed_{kaggle_data}"
# print(kaggle_data)
# df = pre_process(data_directory,kaggle_data,output_file)

data = ['2019-Oct.csv','2019-Nov.csv','2019-Dec.csv','2020-Jan.csv','2020-Feb.csv','2020-Mar.csv','2020-Apr.csv']
total_df = None
for dt in data:
    t_data = f"./proceessed_{dt}"
    print(t_data)
    df = pd.read_csv(t_data)
    if total_df is None:
        total_df = df
    else:
        total_df = pd.concat([total_df, df], ignore_index=True)
        
#  #删除重复行
print_statistics(total_df)
total_df.drop_duplicates(subset=['user_id', 'product_id', 'event_type'], keep='first', inplace=True)
print_statistics(total_df)
total_df=total_df.sort_values(by='event_time')
total_df.to_csv('total.csv', index=False)

df = pd.read_csv('total.csv')
df['timestamp'] = pd.to_datetime(df['event_time'])
df['timestamp'] = df['timestamp'].astype(np.int64) // 10**9  # 转换为时间戳（秒）
df.rename(columns={'product_id': 'item_id', 'event_type': 'action_type'}, inplace=True)
df['action_type'] = df['action_type'].map({'view': 0, 'cart': 1, 'purchase': 2})
df.sort_values(by='timestamp', inplace=True)
print("数据导入处理完成：")
print_statistics2(df)
print('====================================================================================')

 # delete buy less than 20
print("删除购买少于20的商品:")
df['is_buy']=df['action_type'].apply(lambda x: 1 if x == 2 else 0)
df['valid_item'] = df.item_id.map(df.groupby('item_id')['is_buy'].sum() >= 20)
df = df.loc[df.valid_item].drop('valid_item', axis=1)
print_statistics2(df)
print('====================================================================================')

print('删除没有购买记录的用户:')
# delete users without purchase
df = df[df.user_id.isin(df[df['action_type'] == 2].user_id.unique())]
print_statistics2(df)
print('====================================================================================')

print('删除购买次数小于10的用户:')
# delete cold-start users with less than 10 purchases
df['valid_session'] = df.user_id.map(df[df['action_type'] == 2].groupby('user_id')['item_id'].size() >= 10)
df = df.loc[df.valid_session].drop('valid_session', axis=1)
print_statistics2(df)
print('====================================================================================')

df = df.sort_values(['timestamp'])
df = df.reset_index(drop=True)

df.to_csv('processed_total.csv', index=False)

df = pd.read_csv('processed_total.csv')
df.sort_values(by='timestamp', inplace=True)

length = len(df)
base_size = int(length * 0.6)
inc1_size = int(length * 0.1)
inc2_size = int(length * 0.1)
inc3_size = int(length * 0.1)

base_data = df.iloc[:base_size]
inc1_data = df.iloc[base_size:base_size + inc1_size]
inc2_data = df.iloc[base_size + inc1_size:base_size + inc1_size + inc2_size]
inc3_data = df.iloc[base_size + inc1_size + inc2_size:base_size + inc1_size + inc2_size + inc3_size]
inc4_data = df.iloc[base_size + inc1_size + inc2_size + inc3_size:]

# 计算基础集中的 'buy' 用户和物品
base_buy_users = base_data[base_data['action_type'] == 2]['user_id'].unique()
base_buy_items = base_data[base_data['action_type'] == 2]['item_id'].unique()

# 移除增量集中在基础集中没有 'buy' 行为的用户和物品
inc1_data = inc1_data[inc1_data['user_id'].isin(base_buy_users) & inc1_data['item_id'].isin(base_buy_items)]
inc2_data = inc2_data[inc2_data['user_id'].isin(base_buy_users) & inc2_data['item_id'].isin(base_buy_items)]
inc3_data = inc3_data[inc3_data['user_id'].isin(base_buy_users) & inc3_data['item_id'].isin(base_buy_items)]
inc4_data = inc4_data[inc4_data['user_id'].isin(base_buy_users) & inc4_data['item_id'].isin(base_buy_items)]

# 重新编码用户ID，确保用户ID是连续的
user_id_map = {user_id: new_id + 1 for new_id, user_id in enumerate(sorted(base_data['user_id'].unique()))}
base_data.loc[:, 'user_id'] = base_data['user_id'].map(user_id_map)
inc1_data.loc[:, 'user_id'] = inc1_data['user_id'].map(user_id_map)
inc2_data.loc[:, 'user_id'] = inc2_data['user_id'].map(user_id_map)
inc3_data.loc[:, 'user_id'] = inc3_data['user_id'].map(user_id_map)
inc4_data.loc[:, 'user_id'] = inc4_data['user_id'].map(user_id_map)

# 重新编码物品ID，确保物品ID是连续的
item_id_map = {item_id: new_id + 1 for new_id, item_id in enumerate(sorted(base_data['item_id'].unique()))}
base_data.loc[:, 'item_id'] = base_data['item_id'].map(item_id_map)
inc1_data.loc[:, 'item_id'] = inc1_data['item_id'].map(item_id_map)
inc2_data.loc[:, 'item_id'] = inc2_data['item_id'].map(item_id_map)
inc3_data.loc[:, 'item_id'] = inc3_data['item_id'].map(item_id_map)
inc4_data.loc[:, 'item_id'] = inc4_data['item_id'].map(item_id_map)


print(len(base_data['user_id'].unique()), len(base_data['item_id'].unique()), base_data.shape[0])
print(len(inc1_data['user_id'].unique()), len(inc1_data['item_id'].unique()), inc1_data.shape[0])
print(len(inc2_data['user_id'].unique()), len(inc2_data['item_id'].unique()), inc2_data.shape[0])
print(len(inc3_data['user_id'].unique()), len(inc3_data['item_id'].unique()), inc3_data.shape[0])
print(len(inc4_data['user_id'].unique()), len(inc4_data['item_id'].unique()), inc4_data.shape[0])
print('====================================================================================')

# =======================写入===============================
output_dir = 'data_processed_inc'
os.makedirs(output_dir, exist_ok=True)
total_users = base_data['user_id'].nunique()
total_items = base_data['item_id'].nunique()
print("user: ", total_users)
print("item: ", total_items)
total_data = [base_data, inc1_data, inc2_data, inc3_data, inc4_data]
all_data = pd.concat(total_data)
print('删除不存在于基础集中的用户和物品后:')
print_statistics2(all_data)

behavior = ['view', 'cart', 'purchase']

def generate(trn,vt,path,behavior,output_dir):

    trn = trn.sort_values(by=['user_id', 'item_id'])
    sub_dir = os.path.join(output_dir, path)
    os.makedirs(sub_dir, exist_ok=True)
    for b in behavior:
        file_path = os.path.join(sub_dir, b + '.txt')
        with open(file_path, 'w') as f:
            for index, row in trn[trn['action_type'] == behavior.index(b)].iterrows():
                f.write(str(row['user_id']) + ' ' + str(row['item_id']) + '\n')
    print(f"{path}:")
    print_statistics2(trn)

    length = len(vt)
    half = int(length / 2)
    valid_data = vt.iloc[:half]
    test_data = vt.iloc[half:]
    valid_data = valid_data.sort_values(by=['user_id', 'item_id']).copy()
    test_data = test_data.sort_values(by=['user_id', 'item_id']).copy()
    file_path = os.path.join(sub_dir, "validation.txt")
    with open(file_path, 'w') as f:
        for index, row in valid_data.iterrows():
            if row['action_type'] == 2:
                f.write(f"{int(row['user_id'])} {int(row['item_id'])}\n")
    file_path = os.path.join(sub_dir, "test.txt")
    with open(file_path, 'w') as f:
        for index, row in test_data.iterrows():
            if row['action_type'] == 2:
                f.write(f"{int(row['user_id'])} {int(row['item_id'])}\n")
    print(f"Generate {path} complete!")


combine_0_1 = pd.concat([base_data, inc1_data])
combine_0_1_2 = pd.concat([base_data, inc1_data, inc2_data])
combine_0_1_2_3 = pd.concat([base_data, inc1_data, inc2_data, inc3_data])

list_generate = [(base_data,inc1_data,'0'),(inc1_data,inc2_data,'1'),(inc2_data,inc3_data,'2'),(inc3_data,inc4_data,'3'),
                    (combine_0_1,inc2_data,"0_1"),(combine_0_1_2,inc3_data,"0_1_2"),(combine_0_1_2_3,inc4_data,"0_1_2_3")]
for i,j,k in list_generate:
    generate(i,j,k,behavior,output_dir)

print("Processing complete!")
# print_statistics2(inc4_data)


